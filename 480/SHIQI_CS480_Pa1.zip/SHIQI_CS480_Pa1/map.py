from search import * # TODO import the necessary classes and methods
import sys

if __name__ == '__main__':
	
	input_file = sys.argv[1]
	search_algo_str = sys.argv[2]
	
	# TODO implement
	
	with open(input_file, 'r') as f:
		lines = f.readlines()

	data = []
	for i in range(len(lines)):
		line = lines[i][:-1]
		if line[0]!='#':
			line = line.split(' ')
			data.append(line)

	graph_map = collections.defaultdict(dict)
	for d in data:
		if len(d)==4:
			node_1, node_2 = d[0], d[1]
			if d[2]=="<>":
				graph_map[node_1][node_2] = int(d[3])
				graph_map[node_2][node_1] = int(d[3])
			else:
				graph_map[node_1][node_2] = int(d[3])
		elif len(d)==2:
			if d[1].isalpha():
				initial = d[0]
				goal = d[1]

	graph = Graph(graph_map, True)

	graphproblem = GraphProblem(initial, goal, graph)

	if search_algo_str=="BFTS":
		goal_node = breadth_first_tree_search(graphproblem) # TODO call the appropriate search function with appropriate parameters
	# Do not change the code below.
	if goal_node is not None:
		print("Solution path", goal_node.solution())
		print("Solution cost", goal_node.path_cost)
	else:
		print("No solution was found.")